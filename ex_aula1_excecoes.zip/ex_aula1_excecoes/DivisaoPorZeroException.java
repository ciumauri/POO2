public class DivisaoPorZeroException extends Exception {
    public DivisaoPorZeroException(){
        super("Impossivel dividir por zero.");
    }
}
