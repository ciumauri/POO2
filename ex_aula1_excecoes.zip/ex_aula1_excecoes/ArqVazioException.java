public class ArqVazioException extends Exception {
    public ArqVazioException(){
        super("O arquivo está vazio...");
    }
}