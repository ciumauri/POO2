public class EncomendaExpressa extends Encomenda {

  private String telefoneContato;

  public EncomendaExpressa(
    int numeroPedido,
    String dataPostagem,
    double peso,
    String telefoneContato
  ) {
    super(numeroPedido, dataPostagem, peso);
    this.setTelefoneContato(telefoneContato);
  }

  public String getTelefoneContato() {
    return telefoneContato;
  }

  public void setTelefoneContato(String telefoneContato) {
    this.telefoneContato = telefoneContato;
  }

  @Override //força o polimorfismo
  public double calculaFrete(double Peso, double Preco) {
    return this.getPeso() * this.preco;
  }
}
