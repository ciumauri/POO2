public interface ImportacaoArquivos {
  public void carregarConfiguracoes(String arqConfig);

  public void importarDados(String arqDadosEntrada);
}
