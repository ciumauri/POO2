public class Encomenda {

  private int numeroPedido;
  private String dataPostagem;
  private double peso;
  protected double preco;

  public Encomenda(int numeroPedido, String dataPostagem, double peso) {
    setNumeroPedido(numeroPedido);
    setDataPostagem(dataPostagem);
    setPeso(peso);
  }

  public int getNumeroPedido() {
    return numeroPedido;
  }

  public void setNumeroPedido(int numeroPedido) {
    this.numeroPedido = numeroPedido;
  }

  public String getDataPostagem() {
    return dataPostagem;
  }

  public void setDataPostagem(String dataPostagem) {
    this.dataPostagem = dataPostagem;
  }

  public double getPeso() {
    return peso;
  }

  public void setPeso(double peso) {
    this.peso = peso;
  }

  public double calculaFrete(double Peso, double Preco) {
    return this.peso * this.preco;
  }
}
