public class Transportadora implements ImportacaoArquivos {

  Encomenda[] vetEncomenda;
  EncomendaExpressa[] vetEncomendaExpressa;

  public static void main(String[] args) throws Exception {}

  @Override
  public void carregarConfiguracoes(String arqConfig) {}

  @Override
  public void importarDados(String arqDadosEntrada) {}
}
