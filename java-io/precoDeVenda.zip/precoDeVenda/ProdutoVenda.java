import java.io.*;
import java.util.Scanner;

public class ProdutoVenda {

  public static void main(String[] args) throws Exception {
    Scanner arquivoDeEntrada = new Scanner(System.in);
    int estoque;
    Float percentual, precoDeVenda, precoDeCusto;
    String entrada, nome, saidaDeVenda, codigo, cabecalho, saidaDeCompra, categoria;

    System.out.println("***** INFORME NOME DO ARQUIVO DE ENTRADA: *****");
    entrada = arquivoDeEntrada.nextLine();

    System.out.println("***** INFORME O PERCENTUAL DE LUCRO: *****");
    percentual = arquivoDeEntrada.nextFloat();
    percentual = percentual / 100;

    String arquivoDeSaida = "venda.csv";
    BufferedWriter arquivoDeCompra = new BufferedWriter(
      new FileWriter(arquivoDeSaida)
    );
    cabecalho = "codigo;nome;precoDeVenda";
    arquivoDeCompra.write(cabecalho);
    arquivoDeCompra.newLine();

    String arquivoDeSaidaDeCompra = "comprar.csv";
    BufferedWriter arquivoDeVenda = new BufferedWriter(
      new FileWriter(arquivoDeSaidaDeCompra)
    );
    cabecalho = "codigo;estoque;nome;custo;categoria";
    arquivoDeVenda.write(cabecalho);
    arquivoDeVenda.newLine();

    BufferedReader arquivoDeLeitura = new BufferedReader(
      new FileReader(entrada)
    );
    String linha;

    while ((linha = arquivoDeLeitura.readLine()) != null) {
      String dados[] = linha.split(";");
      codigo = dados[0];
      nome = dados[2];
      precoDeCusto = Float.parseFloat(dados[3]);
      estoque = Integer.parseInt(dados[1]);
      categoria = dados[4];
      precoDeVenda = precoDeCusto + (percentual * precoDeCusto);

      if (estoque < 10) {
        saidaDeCompra =
          codigo +
          ";" +
          estoque +
          ";" +
          nome +
          ";" +
          precoDeCusto +
          ";" +
          categoria;
        arquivoDeVenda.write(saidaDeCompra);
        arquivoDeVenda.newLine();
      }

      saidaDeVenda = codigo + ";" + nome + ";" + precoDeVenda;

      arquivoDeCompra.write(saidaDeVenda);
      arquivoDeCompra.newLine();
    }

    arquivoDeCompra.close();
    arquivoDeVenda.close();
  }
}
