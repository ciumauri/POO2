public class Locadora {
    public static void main(String[] args) {
        DaoVeiculo daoVeiculo = new DaoVeiculo();
        Veiculo v1 = new Veiculo();
        v1.setAno(2002);
        v1.setChassi("12341234");
        v1.setMarca("Ford");
        v1.setModelo("Focus");

        daoVeiculo.inserir(v1);
    }
}
